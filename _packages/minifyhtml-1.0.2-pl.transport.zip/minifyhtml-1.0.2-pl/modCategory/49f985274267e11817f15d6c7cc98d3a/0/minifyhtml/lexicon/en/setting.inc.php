<?php
$_lang['area_minifyhtml.main'] = 'Main';

$_lang['setting_minifyhtml.exclude'] = 'Exclude docs';
$_lang['setting_minifyhtml.exclude_desc'] = 'List of document, separated by coma, excluded from minification.';
$_lang['setting_minifyhtml.newlines'] = 'Remove newlines';
$_lang['setting_minifyhtml.newlines_desc'] = 'Will remove all new lines symbols from output. Default true.';
$_lang['setting_minifyhtml.doubles'] = 'Remove space characters doubles';
$_lang['setting_minifyhtml.doubles_desc'] = 'Will replace space characters doubles in output with last one. Default false.';