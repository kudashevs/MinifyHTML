<?php
$_lang['area_minifyhtml.main'] = 'Основные';

$_lang['setting_minifyhtml.exclude'] = 'Исключить документы';
$_lang['setting_minifyhtml.exclude_desc'] = 'Список документов через запятую, к которым не применять минификацию.';
$_lang['setting_minifyhtml.newlines'] = 'Удалять символы новой строки';
$_lang['setting_minifyhtml.newlines_desc'] = 'Удалит все символы новой строки из обрабатываемого вывода. По умолчанию true.';
$_lang['setting_minifyhtml.doubles'] = 'Удалять дубли пробельных символов';
$_lang['setting_minifyhtml.doubles_desc'] = 'Заменит дубли пробельных символов в обрабатываемом выводе последним. По умолчанию false.';