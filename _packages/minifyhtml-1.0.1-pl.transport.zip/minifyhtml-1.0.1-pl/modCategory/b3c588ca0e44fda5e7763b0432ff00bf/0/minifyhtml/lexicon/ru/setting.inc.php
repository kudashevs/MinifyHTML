<?php
$_lang['area_minifyhtml.main'] = 'Основные';

$_lang['setting_minifyhtml.exclude'] = 'Исключить документы';
$_lang['setting_minifyhtml.exclude_desc'] = 'Список документов через запятую, к которым не применять минификацию.';