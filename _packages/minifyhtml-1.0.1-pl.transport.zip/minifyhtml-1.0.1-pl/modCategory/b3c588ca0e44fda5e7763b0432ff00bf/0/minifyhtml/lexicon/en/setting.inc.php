<?php
$_lang['area_minifyhtml.main'] = 'Main';

$_lang['setting_minifyhtml.exclude'] = 'Exclude docs';
$_lang['setting_minifyhtml.exclude_desc'] = 'List of document, separated by coma, excluded from minification.';