--------------------
MinifyHTML
--------------------
Author: Kudashev Serge <kudashevs@gmail.com>
--------------------

MODx Revolution plugin which remove unnecessary space symbols (minify) from output HTML code.

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/MinifyHTML/issues